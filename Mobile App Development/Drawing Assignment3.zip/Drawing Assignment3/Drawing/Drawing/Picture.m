//
//  Picture.m
//  Drawing
//
//  Created by Ileana Palesi on 10/12/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "Picture.h"

#define frameWidth self.frame.size.width
#define frameHeight self.frame.size.height

@implementation Picture
@synthesize val;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [self drawBackground];
    [self rect];
    [self triangles];
    [self arch];
}

- (void) drawBackground
{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGRect sky = CGRectMake(0, 0, frameWidth, frameHeight);
    CGContextAddRect(ctx, sky);
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithRed:.11 green:.29 blue: .62 alpha: 1.0].CGColor);
    CGContextFillPath(ctx);
}

- (void) rect
{
    //building from the bottom layer up
    val = 28;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGRect rect1 = CGRectMake(180, frameHeight-val, 400, val);
    CGContextAddRect(ctx, rect1);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    CGRect rect2 = CGRectMake(180, frameHeight-(val*2+4), 400, val);
    CGContextAddRect(ctx, rect2);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect3
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 180, frameHeight-(val*3.4));
    CGContextAddLineToPoint(ctx, frameWidth-160, frameHeight-(val*3.4));
    CGContextAddLineToPoint(ctx, frameWidth-140, frameHeight-(val*2+8));
    CGContextAddLineToPoint(ctx, 160, frameHeight-(val*2+8));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect4
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 240, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, frameWidth-210, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, frameWidth-200, frameHeight-(val*4.4));
    CGContextAddLineToPoint(ctx, frameWidth-190, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, frameWidth-175, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, frameWidth-161, frameHeight-(val*3.4+4));
    CGContextAddLineToPoint(ctx, 235, frameHeight-(val*3.4+4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 232, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, 290, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, 282, frameHeight-(val*5.6));
    CGContextAddLineToPoint(ctx, 280, frameHeight-(val*5.2));
    CGContextAddLineToPoint(ctx, 302, frameHeight-(val*5.2));
    CGContextAddLineToPoint(ctx, 305, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-280, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-270, frameHeight-(val*6));
    CGContextAddLineToPoint(ctx, frameWidth-270, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-250, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-240, frameHeight-(val*4.9+1));
    CGContextAddLineToPoint(ctx, 243, frameHeight-(val*4.9+1));
    CGContextAddLineToPoint(ctx, 240, frameHeight-(val*5.6));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 325, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, frameWidth-290, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, frameWidth-280, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, 330, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, 330, frameHeight-(val*7.4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect7
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 325, frameHeight-(val*7.9+1));
    CGContextAddLineToPoint(ctx, 320, frameHeight-(val*8.2));
    CGContextAddLineToPoint(ctx, 335, frameHeight-(val*8.2));
    CGContextAddLineToPoint(ctx, 325, frameHeight-(val*8.5));
    
    CGContextAddLineToPoint(ctx, 340, frameHeight-(val*9.6));
    CGContextAddLineToPoint(ctx, 345, frameHeight-(val*9.6));
    
    CGContextAddLineToPoint(ctx, 360, frameHeight-(val*8.5));
    CGContextAddLineToPoint(ctx, 350, frameHeight-(val*8.2));
    CGContextAddLineToPoint(ctx, 360, frameHeight-(val*8.2));
    
    CGContextAddLineToPoint(ctx, 363, frameHeight-(val*8.5));
    CGContextAddLineToPoint(ctx, 366, frameHeight-(val*9.3));
    CGContextAddLineToPoint(ctx, 370, frameHeight-(val*8.6));
    CGContextAddLineToPoint(ctx, 375, frameHeight-(val*8.3));
    
    CGContextAddLineToPoint(ctx, 375, frameHeight-(val*9));
    CGContextAddLineToPoint(ctx, 385, frameHeight-(val*9.2));
    CGContextAddLineToPoint(ctx, 385, frameHeight-(val*9.6));
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*9.6));
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*9.2));
    CGContextAddLineToPoint(ctx, 440, frameHeight-(val*9));
    CGContextAddLineToPoint(ctx, frameWidth-290, frameHeight-(val*7.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect8
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 385, frameHeight-(val*9.7+1));
    CGContextAddLineToPoint(ctx, 385, frameHeight-(val*10.6));
    CGContextAddLineToPoint(ctx, 380, frameHeight-(val*10.7));
    CGContextAddLineToPoint(ctx, 375, frameHeight-(val*11));
    CGContextAddLineToPoint(ctx, 385, frameHeight-(val*11));
    
    CGContextAddLineToPoint(ctx, 385, frameHeight-(val*11.4));
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*11.4));
    
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*11));
    CGContextAddLineToPoint(ctx, 440, frameHeight-(val*11));
    CGContextAddLineToPoint(ctx, 435, frameHeight-(val*10.7));
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*10.6));
    CGContextAddLineToPoint(ctx, 430, frameHeight-(val*9.7+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
}

- (void) triangles
{
    val = 28;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    //rect4 tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 190, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, 200, frameHeight-(val*4.8));
    CGContextAddLineToPoint(ctx, 210, frameHeight-(val*3.4+4));
    CGContextAddLineToPoint(ctx, 181, frameHeight-(val*3.4+4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5 right big tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-230, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-220, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-211, frameHeight-(val*4.9+1));
    CGContextAddLineToPoint(ctx, frameWidth-235, frameHeight-(val*4.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5 left small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 195, frameHeight-(val*5.5));
    CGContextAddLineToPoint(ctx, 200, frameHeight-(val*4.9+1));
    CGContextAddLineToPoint(ctx, 190, frameHeight-(val*4.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5 left flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 165, frameHeight-(val*6));
    CGContextAddLineToPoint(ctx, 195, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, 195, frameHeight-(val*5.8));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5 right small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-182.5, frameHeight-(val*5.5));
    CGContextAddLineToPoint(ctx, frameWidth-176, frameHeight-(val*4.9+1));
    CGContextAddLineToPoint(ctx, frameWidth-189, frameHeight-(val*4.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect5 right flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-212.5, frameHeight-(val*6.2));
    CGContextAddLineToPoint(ctx, frameWidth-182.5, frameHeight-(val*6.4));
    CGContextAddLineToPoint(ctx, frameWidth-182.5, frameHeight-(val*6));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6 right small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-225, frameHeight-(val*7.6));
    CGContextAddLineToPoint(ctx, frameWidth-221, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, frameWidth-229, frameHeight-(val*6.3+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6 right flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-255, frameHeight-(val*8));
    CGContextAddLineToPoint(ctx, frameWidth-225, frameHeight-(val*8.2));
    CGContextAddLineToPoint(ctx, frameWidth-225, frameHeight-(val*7.8));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6 right big tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-264, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, frameWidth-256, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, frameWidth-245, frameHeight-(val*7.2));
    CGContextAddLineToPoint(ctx, frameWidth-248, frameHeight-(val*7));
    CGContextAddLineToPoint(ctx, frameWidth-250, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, frameWidth-270, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, frameWidth-272, frameHeight-(val*7));
    CGContextAddLineToPoint(ctx, frameWidth-275, frameHeight-(val*7.2));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6 left small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 315, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, 324, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, 306, frameHeight-(val*6.3+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect6 left big tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 252, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, 268, frameHeight-(val*7.8));
    CGContextAddLineToPoint(ctx, 276, frameHeight-(val*7));
    CGContextAddLineToPoint(ctx, 286, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, 237, frameHeight-(val*6.3+1));
    CGContextAddLineToPoint(ctx, 245, frameHeight-(val*7));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect7 left small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 260, frameHeight-(val*8.6));
    CGContextAddLineToPoint(ctx, 267, frameHeight-(val*7.9+1));
    CGContextAddLineToPoint(ctx, 253, frameHeight-(val*7.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect7 left flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 230, frameHeight-(val*9.2));
    CGContextAddLineToPoint(ctx, 260, frameHeight-(val*9.4));
    CGContextAddLineToPoint(ctx, 260, frameHeight-(val*9));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect7 right small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-260, frameHeight-(val*8.6));
    CGContextAddLineToPoint(ctx, frameWidth-256, frameHeight-(val*7.9+1));
    CGContextAddLineToPoint(ctx, frameWidth-264, frameHeight-(val*7.9+1));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect7 right flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, frameWidth-290, frameHeight-(val*9.2));
    CGContextAddLineToPoint(ctx, frameWidth-260, frameHeight-(val*9.4));
    CGContextAddLineToPoint(ctx, frameWidth-260, frameHeight-(val*9));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect8 left small tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 342.5, frameHeight-(val*9.9));
    CGContextAddLineToPoint(ctx, 340, frameHeight-(val*9.6+4));
    CGContextAddLineToPoint(ctx, 345, frameHeight-(val*9.6+4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //rect8 left flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 312.5, frameHeight-(val*10.4));
    CGContextAddLineToPoint(ctx, 342.5, frameHeight-(val*10.2));
    CGContextAddLineToPoint(ctx, 342.5, frameHeight-(val*10.6));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //top tower
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 407.5, frameHeight-(val*13.8));
    CGContextAddLineToPoint(ctx, 440, frameHeight-(val*11.4+4));
    CGContextAddLineToPoint(ctx, 375, frameHeight-(val*11.4+4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
    
    //top flag
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, 377.5, frameHeight-(val*14.2));
    CGContextAddLineToPoint(ctx, 407.5, frameHeight-(val*14));
    CGContextAddLineToPoint(ctx, 407.5, frameHeight-(val*14.4));
    CGContextClosePath(ctx);
    CGContextSetFillColorWithColor(ctx, [UIColor whiteColor].CGColor);
    CGContextFillPath(ctx);
}

- (void) arch {
    val = 28;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGRect arch = CGRectMake(280, frameHeight-(val*3.1), 190, 200);
    CGContextAddEllipseInRect(ctx, arch);
    CGContextSetFillColorWithColor(ctx, [UIColor colorWithRed:.11 green:.29 blue: .62 alpha: 1.0].CGColor);
    CGContextFillPath(ctx);
}
@end
