//
//  AppDelegate.h
//  Drawing
//
//  Created by Ileana Palesi on 10/12/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

