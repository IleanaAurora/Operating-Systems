//
//  ViewController.m
//  Drawing
//
//  Created by Ileana Palesi on 10/12/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "ViewController.h"

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height

@interface ViewController ()

@end

@implementation ViewController
@synthesize pic;

- (void)viewDidLoad {
    [super viewDidLoad];
    pic = [[Picture alloc] initWithFrame: CGRectMake(0, 0, frameWidth, frameHeight)];
    self.view = pic;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    //return YES; // Any orientation ok
    return (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
