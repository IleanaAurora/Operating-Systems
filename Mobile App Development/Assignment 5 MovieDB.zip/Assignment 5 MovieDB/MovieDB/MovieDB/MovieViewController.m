//
//  MovieViewController.m
//  MovieDB
//
//  Created by Ileana Palesi on 11/10/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "MovieViewController.h"

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height


@interface MovieViewController ()
@end

@implementation MovieViewController
@synthesize clip;

- (id) initWithDelegate: (id) del
{
    if (self = [super init])
    {
        self.view.backgroundColor = [UIColor colorWithRed: .26 green: .81 blue: .14 alpha: 1];
        myVidPlayer = nil;
        delegate = del;
    }
    return self;
}


/*- (void) navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)vController animated:(BOOL)animated
{
    [vController viewWillAppear:animated];
}*/


- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden: YES];
    NSArray *docsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [docsPath objectAtIndex: 0];
    NSString *videoFilePath  = [NSString stringWithFormat:@"%@/%@.mp4", docsDir, clip.name];
    NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: videoFilePath];
    //NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: clip.url];
    myVidPlayer = [[MPMoviePlayerController alloc] initWithContentURL: fileURL];
    myVidPlayer.view.frame = CGRectMake(5.0, 5.0, frameWidth, frameHeight);
    myVidPlayer.initialPlaybackTime = 0;
    myVidPlayer.scalingMode = MPMovieScalingModeAspectFit;
    [self.view addSubview: myVidPlayer.view];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(vidDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object: myVidPlayer];
    [myVidPlayer play];
}


- (void) vidDidFinish:(NSNotification*)notification
{
    //[self resetMovieView];
    //[delegate cleanup];
    [self.navigationController setNavigationBarHidden: NO];
    [self viewWillDisappear: YES];
    [self.navigationController popViewControllerAnimated: YES];
}


-(void) resetMovieView
{
    /*if (myVidPlayer != nil)
    {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:myVidPlayer];
        myVidPlayer.initialPlaybackTime = 0;
        [myVidPlayer.view removeFromSuperview];
        [myVidPlayer stop];
        myVidPlayer = nil;
    }*/
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

@end
