//
//  NSManagedObject+CoreDataProperties.m
//  MovieDB
//
//  Created by Ileana Palesi on 11/10/18.
//  Copyright © 2018 Iona. All rights reserved.
//
//

#import "Item.h"

@implementation Item

@dynamic name;
@dynamic vidDescription;
@dynamic url;

@end
