//
//  EditViewController.h
//  MovieDB
//
//  Created by Ileana Palesi on 11/9/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Item.h"
#import "MovieViewController.h"

@interface EditViewController : UIViewController <UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    UILabel *lbl1, *lbl2;
    UITextField *vidName;
    UITextField *vidDescription;
    UIButton *done, *vidBtn, *playVidBtn;
    Item *item;
    MovieViewController *mv;
}

@property(nonatomic, strong) UILabel *lbl1, *lbl2;
@property(nonatomic, strong) UIButton *done;
@property(nonatomic, strong) UIButton *playVidBtn;
@property(nonatomic, strong) UITextField *vidName;
@property(nonatomic, strong) UITextField *vidDescription;
@property(nonatomic, strong) Item *item;
@property(nonatomic, strong) MovieViewController *mv;
@property (strong, nonatomic) NSString *vidURL;

- (void) cleanup;

@end
