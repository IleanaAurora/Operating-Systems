//
//  RootViewController.h
//  MovieDB
//
//  Created by Ileana Palesi on 11/9/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditViewController.h"
#import "ViewControllerDelegate.h"

@interface RootViewController : UITableViewController <UINavigationControllerDelegate>
{
    NSMutableArray *vidClips;
    NSManagedObjectContext *managedObjectContext;
    EditViewController *editViewCtrl;
    Item *clip;
}

@property(nonatomic, strong) NSMutableArray *vidClips;
@property(nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property(nonatomic, strong) EditViewController *editViewCtrl;

- (void) addItem;

@end
