//
//  NSManagedObject+CoreDataProperties.h
//  MovieDB
//
//  Created by Ileana Palesi on 11/10/18.
//  Copyright © 2018 Iona. All rights reserved.
//
//

#import "CoreData/CoreData.h"


@interface Item : NSManagedObject
{
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *vidDescription;
@property (nonatomic, retain) NSString *url;

@end

