//
//  EditViewController.m
//  MovieDB
//
//  Created by Ileana Palesi on 11/9/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "EditViewController.h"
#import "Item.h"
#import <MobileCoreServices/MobileCoreServices.h>

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height

@implementation EditViewController
@synthesize lbl1, lbl2;
@synthesize vidName;
@synthesize vidDescription;
@synthesize done;
@synthesize playVidBtn;
@synthesize item;
@synthesize mv;

bool donePressed = NO;
- (id) init
{
    if (self = [super init])
    {
        self.view.backgroundColor = [UIColor colorWithRed: .75 green: .90 blue: .85 alpha: 1.0];
        
        lbl1 = [[UILabel alloc] initWithFrame: CGRectMake(10, 70, 100, 30)];
        lbl1.text = @"Video Name";
        lbl1.font = [UIFont fontWithName: @"Helvetica" size: 18];
        lbl1.textColor = [UIColor blueColor];
        [self.view addSubview: lbl1];
        
        vidName = [[UITextField alloc] initWithFrame: CGRectMake(120, 70, frameWidth*.5, 30)];
        vidName.borderStyle = UITextBorderStyleRoundedRect;
        vidName.textColor = [UIColor purpleColor];
        vidName.delegate = self;
        [self.view addSubview: vidName];
        
        
        lbl2 = [[UILabel alloc] initWithFrame: CGRectMake(10, 140, 100, 30)];
        lbl2.text = @"Description";
        lbl2.font = [UIFont fontWithName: @"Helvetica" size: 18];
        lbl2.textColor = [UIColor blueColor];
        [self.view addSubview: lbl2];
        
        vidDescription = [[UITextField alloc] initWithFrame: CGRectMake(120, 140, frameWidth*.5, 30)];
        vidDescription.borderStyle = UITextBorderStyleRoundedRect;
        vidDescription.textColor = [UIColor purpleColor];
        vidDescription.delegate = self;
        [self.view addSubview: vidDescription];

        
        vidBtn = [UIButton buttonWithType: UIButtonTypeRoundedRect];
        vidBtn.frame = CGRectMake(0, 0, 120, 40);
        vidBtn.center = CGPointMake(frameWidth/2.0, frameHeight - 100);
        vidBtn.opaque = YES;
        vidBtn.layer.cornerRadius = 12;
        vidBtn.clipsToBounds = YES;
        vidBtn.backgroundColor = [UIColor blueColor];
        vidBtn.tintColor = [UIColor whiteColor];
        [vidBtn setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [vidBtn.titleLabel setFont:[UIFont systemFontOfSize: 22]];
        [vidBtn setTitle:@"Record" forState:UIControlStateNormal];
        [vidBtn addTarget:self action:@selector(takeVideo:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview: vidBtn];
        
        
        done = [UIButton buttonWithType: UIButtonTypeRoundedRect];
        done.frame = CGRectMake(0, 0, 120, 40);
        done.center = CGPointMake(frameWidth/2.0, frameHeight - 50);
        done.opaque = YES;
        done.layer.cornerRadius = 12;
        done.clipsToBounds = YES;
        done.backgroundColor = [UIColor blueColor];
        done.tintColor = [UIColor whiteColor];
        [done setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [done.titleLabel setFont:[UIFont systemFontOfSize: 22]];
        [done setTitle:@"Done" forState:UIControlStateNormal];
        [done addTarget:self action:@selector(finishedEditing) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview: done];
        
        playVidBtn = [UIButton buttonWithType: UIButtonTypeRoundedRect];
        playVidBtn.frame = CGRectMake(0, 0, 120, 40);
        playVidBtn.center = CGPointMake(frameWidth/2.0, frameHeight - 150);
        playVidBtn.opaque = YES;
        playVidBtn.layer.cornerRadius = 12;
        playVidBtn.clipsToBounds = YES;
        playVidBtn.backgroundColor = [UIColor blueColor];
        playVidBtn.tintColor = [UIColor whiteColor];
        [playVidBtn setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [playVidBtn.titleLabel setFont:[UIFont systemFontOfSize: 22]];
        [playVidBtn setTitle:@"Play Video" forState:UIControlStateNormal];
        [playVidBtn addTarget:self action:@selector(vidPlayer:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview: playVidBtn];
        
    }
    
    return self;
}


- (void) finishedEditing
{
    donePressed = YES;
    [self viewWillDisappear: YES];
}



- (void) viewWillAppear: (BOOL) animated
{
    [super viewWillAppear: animated];
    vidName.text = item.name;
    vidDescription.text = item.vidDescription;
    donePressed = NO;
}



- (void)viewWillDisappear:(BOOL)animated
{
    item.name = vidName.text;
    item.vidDescription = vidDescription.text;
    NSManagedObjectContext *context = item.managedObjectContext;
    NSError *error = nil;
    [context save: &error];
    if(donePressed)
    {
        [self.navigationController popViewControllerAnimated: YES];
        [super viewWillDisappear: YES];
    }
}



- (void) textFieldDidEndEditing: (UITextField *) txtField
{
    if (txtField == vidName)
        item.name = txtField.text;
    else if (txtField == vidDescription)
        item.vidDescription = txtField.text;
}



- (BOOL) textFieldShouldReturn: (UITextField *) txtField {
    [txtField resignFirstResponder];
    return YES;
}



- (void) takeVideo:(UIButton *)sender
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        [myAlertView show];
    }
    else
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.delegate = self;
        picker.allowsEditing = YES;
        
        NSArray *mediaTypes = [[NSArray alloc]initWithObjects:(NSString *)kUTTypeMovie, nil];
        
        picker.mediaTypes = mediaTypes;
        
        [self presentViewController: picker animated: YES completion: NULL];
    }
}



#pragma mark - Image Picker Controller delegate methods

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSURL *chosenMovie = [info objectForKey:UIImagePickerControllerMediaURL];
    NSArray *docsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [docsPath objectAtIndex: 0];
    NSString *loc = [NSString stringWithFormat:@"%@/%@.mp4", docsDir, item.name];
    NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: loc];
    item.url = loc;
    NSData *movieData = [NSData dataWithContentsOfURL:chosenMovie];
    [movieData writeToURL:fileURL atomically:YES];
    
    [picker dismissViewControllerAnimated: YES completion: nil];
}



- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated: YES completion: nil];
}


- (void)vidPlayer:(UIButton *)sender
{
    if(item.url == NULL)
    {
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"No video is stored. Please record video first."
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        [myAlertView show];
    }
    else
    {
        mv = [[MovieViewController alloc] init];
        //mv.vidURL = item.url;
        mv.clip = item;
        [self.navigationController pushViewController:mv animated:YES];
    }
}

- (void) cleanup;
{
    //[self.navigationController popViewControllerAnimated: YES];
    //mv = nil;
}

@end
