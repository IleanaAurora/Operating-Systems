//
//  MovieViewController.h
//  MovieDB
//
//  Created by Ileana Palesi on 11/10/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MediaPlayer/MPMediaPlayback.h>
#import "ViewControllerDelegate.h"
#import "Item.h"

@interface MovieViewController : UIViewController <UIImagePickerControllerDelegate>
{
    Item *clip;
    MPMoviePlayerController *myVidPlayer;
    __weak NSObject<ViewControllerDelegate> *delegate;
    //NSURL *vidURL;
}

@property(nonatomic, strong) Item *clip;
@property(nonatomic, strong)NSIndexPath *indexPath;
@property(nonatomic, retain) NSString *vidURL;

- (id) initWithDelegate:(id)pDel;

@end
