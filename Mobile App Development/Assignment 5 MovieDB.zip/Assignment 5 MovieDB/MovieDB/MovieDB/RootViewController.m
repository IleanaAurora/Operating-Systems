//
//  RootViewController.m
//  MovieDB
//
//  Created by Ileana Palesi on 11/9/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "RootViewController.h"
#import "Item.h"

@interface RootViewController ()

@end

@implementation RootViewController
@synthesize vidClips;
@synthesize managedObjectContext;
@synthesize editViewCtrl;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"VIDEO CLIPS";
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemAdd target:self action:@selector(addItem)];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName: @"Item" inManagedObjectContext: managedObjectContext];
    request.entity = entity;
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey: @"name" ascending: YES];
    NSArray *sortDescriptors = [NSArray arrayWithObjects: sortDescriptor, nil];
    request.sortDescriptors = sortDescriptors;
    NSError *error = nil;
    vidClips = [[managedObjectContext executeFetchRequest: request error: &error] mutableCopy];
    
    editViewCtrl = [[EditViewController alloc] init];
}

- (void) addItem
{
    Item *newClip = [NSEntityDescription insertNewObjectForEntityForName: @"Item" inManagedObjectContext: managedObjectContext];
    NSError *error = nil;
    [managedObjectContext save: &error];
    
    [vidClips insertObject: newClip atIndex: 0];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow: 0 inSection: 0];
    [self.tableView insertRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation: UITableViewRowAnimationFade];
}

- (void) viewWillAppear: (BOOL) animated
{
    [super viewWillAppear: animated];
    if(editViewCtrl.item)
    {
        NSIndexPath *path = [NSIndexPath indexPathForRow: [vidClips indexOfObject: editViewCtrl.item] inSection: 0];
        NSArray *paths = [NSArray arrayWithObjects: path, nil];
        [self.tableView reloadRowsAtIndexPaths: paths withRowAnimation: NO];
        editViewCtrl.item = nil;
    }
}



#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return vidClips.count;
}


- (UITableViewCell *)tableView: (UITableView *) tableView cellForRowAtIndexPath: (NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: CellIdentifier];
    
    Item *newClip = [vidClips objectAtIndex: indexPath.row];
    if (newClip.name == nil)
        cell.textLabel.text = @"New Item";
    else
        cell.textLabel.text = newClip.name; //[NSString stringWithFormat:@"%@", vidClips.name];
    
    cell.textLabel.font = [UIFont fontWithName: @"AvenirNext-Medium" size: 20];
    cell.textLabel.textColor = [UIColor blueColor];
    cell.textLabel.highlightedTextColor = [UIColor yellowColor];
    cell.imageView.image = [UIImage imageNamed: @"Video.png"];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    editViewCtrl.item = [vidClips objectAtIndex: indexPath.row];
    [self.navigationController pushViewController: editViewCtrl animated:YES];
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [managedObjectContext deleteObject: [vidClips objectAtIndex: indexPath.row]];
        NSError *error = nil;
        [managedObjectContext save: &error];
        
        [vidClips removeObjectAtIndex: indexPath.row];
        
        [tableView deleteRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation: YES];
    }
}


@end
