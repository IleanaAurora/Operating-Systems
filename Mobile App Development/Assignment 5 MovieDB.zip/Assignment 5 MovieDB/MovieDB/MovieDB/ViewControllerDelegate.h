//
//  ViewControllerDelegate.h
//  MovieDB
//
//  Created by Ileana Palesi on 11/10/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ViewControllerDelegate <NSObject>
@optional
- (void) cleanup;
@end

